/*
* 
* Author: Tianyu Huang
* Project: Free Form Deformation
*
*/


Controls:

	Keyboard:
		1: Display Icosahedron
		2: Display Torus

		9: decrease size of control volumn
		0: increase size of control volumn

		z: zoom in
		x: zoom out
		c: turn on/off control points and lattis
		v: turn on/off axis (Red=x,Green=y,Blue=z)

		s: switch between wire frame and solid frame
		a: turn on/off original model display

		j/i: stretch
		k/o: bend
		l/p: twist

		w: clear screen
		q: quit


	Mouse:
		right button: drag to rotate
		left button: drag to move control point
